import json
import os

def read_json(path, filename):
    """
    Read a json and return a object created from it.
    Args:
        file path and file name
    
    Returns: json object.
    """
    try:
        with open(path + os.sep + filename +".json", "r+", encoding="latin-1") as outfile:
            json_readed = json.load(outfile)
        return json_readed
    except Exception as error:
        raise ValueError(error)

def dataframe_to_json(dataframe, path, filename):
    """
    Function that returns a json from a dataframe
    """
    return dataframe.to_json(path + os.sep + filename) 


def convert_to_json(dataframe):
    """
    """
    result = dataframe.to_json(orient="split")
    parsed = json.loads(result)
    json.dumps(parsed, indent=4)  


def save_json(path, filename, my_json):
    """
    This functions saves a json file given its name as parameter....etc

    """
    json_data = (path + os.sep + "reports" + os.sep + filename + ".json")
    with open(f"{json_data}", 'a+', encoding="latin-1") as outfile:
        json.dump(my_json, outfile, indent=4)
    return "file saved as json"

