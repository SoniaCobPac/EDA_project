import pandas as pd 
import seaborn as sns
import squarify
import matplotlib.pyplot as plt
import os
import sys
import numpy as np 

sep = os.sep

route = __file__
for i in range(3):
    route = os.path.dirname(route)
sys.path.append(route)


#--------------------------------------AIR GRAPHS------------------------------------------------
   

# Outliers by group
def outliers_plot(dataframe, pollutant, pollutant1, pollutant2, pollutant3, pollutant4):
    """
    This functions plots the outliers in any graph

    Param: Pollutant names as string
    """
    #data to plot divided by pollutant
    pollut = dataframe.loc[dataframe["POLLUTANT"] == pollutant]
    pollut1 = dataframe.loc[dataframe["POLLUTANT"] == pollutant1]
    pollut2 = dataframe.loc[dataframe["POLLUTANT"] == pollutant2]
    pollut3 = dataframe.loc[dataframe["POLLUTANT"] == pollutant3]
    pollut4 = dataframe.loc[dataframe["POLLUTANT"] == pollutant4]

    f, axes = plt.subplots(3, 2, figsize=(15,10), sharex=False)
    axes1 = sns.boxplot(pollut["VALUE"], color = "blue", ax = axes[0,0])
    axes2 = sns.boxplot(pollut1["VALUE"], color = "red", ax = axes[0,1])
    axes3 = sns.boxplot(pollut2["VALUE"], color = "grey", ax = axes[1,0])
    axes4 = sns.boxplot(pollut3["VALUE"], color = "green", ax = axes[1,1])
    axes5 = sns.boxplot(pollut4["VALUE"], color = "gold", ax = axes[2,0])

    #Labels
    axes1.set_title(f"{pollutant} CONCENTRATION (µg/m3)")
    axes2.set_title(f"{pollutant1} CONCENTRATION (µg/m3)")
    axes3.set_title(f"{pollutant2} CONCENTRATION (µg/m3)")
    axes4.set_title(f"{pollutant3} CONCENTRATION (µg/m3)")
    axes5.set_title(f"{pollutant4} CONCENTRATION (µg/m3)")

    axes1.set(xlabel=None)
    axes2.set(xlabel=None)
    axes3.set(xlabel=None)
    axes4.set(xlabel=None)
    axes5.set(xlabel=None)

    axes1.figure.savefig(route + sep + "reports" + sep + "all_outliers.png")
    
    return plt.show()


def outliers(dataframe, pollutant):
    """
    This functions calculates the outliers in a grah

    Param: The dataframe to study and the pollutant to analyse
    """
    # Percentiles
    Q1 = dataframe.quantile(0.25)
    Q3 = dataframe.quantile(0.75)
    #Interquartile range
    IQR_RIC = Q3 - Q1
    lower_limit = (Q1 - 1.5 * IQR_RIC)
    upper_limit = (Q3 + 1.5 * IQR_RIC)

    # Values outside the interquartile range:
    df = dataframe[((dataframe < lower_limit) | (dataframe > upper_limit)).any(axis=1)]

    print("Max value:", df[pollutant].quantile(1))         
    ax = sns.boxplot(x=df[pollutant])
    
    ax.figure.savefig(route + sep + "reports" + sep + f"{pollutant}_outlier.png")

    return plt.show() 

def outliers_calc(dataframe):
    """
    This functions compares the shape of the graph with and withouth outliers
    """
    # Percentiles
    Q1 = dataframe.quantile(0.25)
    Q3 = dataframe.quantile(0.75)
    #Interquartile range
    IQR = Q3 - Q1
  
    df2 = dataframe[~((dataframe < (Q1 - 1.5 * IQR)) |(dataframe > (Q3 + 1.5 * IQR))).any(axis=1)]
    print(dataframe.shape)
    return df2.shape


def pollutant_evolution_all(dataframe, xaxis, yaxis, hue, style, pollutant):
    """
    This functions creates a lineplot showing different pollutants
    """
    plt.figure(figsize=(10,7))
    ax = sns.lineplot(data=dataframe, x=xaxis, y=yaxis, hue=hue, style=style, linewidth = 3)

    plt.ylabel(f"{pollutant} CONCENTRATION (µg/m3)")
    plt.legend(loc = "best")
    plt.title("GAS CONCENTRATION EVOLUTION")

    ax.figure.savefig(route + sep + "reports" + sep + "pollutant_evol.png")

    return plt.show()

def pollutant_evolution_one(dataframe, pollutant):
    """
    This function shows a lineplot of one given pollutant
    """
    plt.figure(figsize=(7,4))
    df = dataframe.groupby("YEAR")[pollutant].mean()  
    ax = sns.lineplot(data=df, linewidth = 3)

    plt.ylabel(f"{pollutant} CONCENTRATION (µg/m3)")
    plt.title(f"{pollutant} CONCENTRATION EVOLUTION")

    ax.figure.savefig(route + sep + "reports" + sep + f"{pollutant}_evol.png")

    return plt.show()


def tree_map(dataframe, pollutant):
    """
    Tree map grouping each region by the concentration amount of a given pollutant
    """
    plt.figure(figsize=(15,10))
    data = dataframe.groupby("REGION").sum()[pollutant].sort_values(ascending=False)[:11]
    colour = ["steelblue", "lightgreen", "purple", "lightblue", "darkblue"]

    ax = squarify.plot(sizes=data.values, label=data.index, alpha=.6, text_kwargs={'fontsize':25}, color=colour)
    plt.axis('off')

    ax.figure.savefig(route + sep + "reports" + sep + f"{pollutant}_treemap.png")

    return plt.show()


#-------------------------------------TEMPERATURE GRAPHS----------------------------------------

def temp_plot(dataframe):
    """
    Function that return a kdeplot showing temperature changes along the studied years
    """
    dataframe = dataframe.T

    dataframe.rename(columns={0:"TEMP 2014", 1: "TEMP 2015", 2: "TEMP 2016", 3: "TEMP 2017", 4: "TEMP 2018", 5: "TEMP 2019"}, inplace=True)
    plt.figure(figsize=(8,5))
    ax = sns.kdeplot(data=dataframe, fill=True, common_norm=False, palette="icefire", alpha=.4, linewidth=0)

    plt.xlabel("MEAN TEMPERATURE (ºc)")

    ax.figure.savefig(route + sep + "reports" + sep + "all_temp.png")

    return plt.show()  

def temp_single(dataframe_section, year):
    """
    Function that shows the change of temperature over a given year
    """
    plt.figure(figsize=(8,5))

    ax = sns.kdeplot(data=dataframe_section, fill=True, common_norm=False, linewidth=1, legend=False)

    plt.xlabel(f"{year} MEAN TEMPERATURE (ºc)")

    ax.figure.savefig(route + sep + "reports" + sep + f"{year}_temp_plot.png")

    return plt.show()


def temp_country(dataframe):
    """
    Change of temperature in the country along the studied years
    """
    plt.figure(figsize=(20,8))
          
    ax = sns.barplot(palette = 'Blues_d', data = dataframe, ci = None)

    ax.figure.savefig(route + sep + "reports" + sep + "mean_temp_evol.png")

    return plt.show()


#-----------------------------------COMPARISON GRAPHS--------------------------------------------

def heatmap(dataframe):
    """
    Correlation graph
    """
    mask = np.triu(np.ones_like(dataframe.corr(), dtype=bool))

    plt.figure(figsize=(15,10))
    # correlation is done only for numeric columns
    ax = sns.heatmap(dataframe.corr(), cmap="coolwarm",annot=True, mask=mask)  

    ax.figure.savefig(route + sep + "reports" + sep + "heatmap_corr.png")

    return plt.show()


def column_tendency(column, column1, column2, column3, column4, column5, column6):
    """
    The function returns a graph showing the tendency of each column. 
    """
    f, axes = plt.subplots(4,2, figsize=(15,10), sharex=False)

    axes1 = sns.distplot(column, color="blue", bins=5, ax = axes[0,0])
    axes2 = sns.distplot(column1, color="red", bins=5, ax = axes[0,1])
    axes3 = sns.distplot(column2, color="grey", bins=5, ax = axes[1,0])
    axes4 = sns.distplot(column3, color="green", bins=5, ax = axes[1,1])
    axes5 = sns.distplot(column4, color="gold", bins=5, ax = axes[2,0])
    axes6 = sns.distplot(column5, color="purple", bins=5, ax = axes[2,1])
    axes7 = sns.distplot(column6, color="brown", bins=5, ax = axes[3,0])

    #Labels
    axes1.set_title("POLLUTANT VALUES")
    axes2.set_title("TEMP 2014")
    axes3.set_title("TEMP 2015")
    axes4.set_title("TEMP 2016")
    axes5.set_title("TEMP 2017")
    axes6.set_title("TEMP 2018")
    axes7.set_title("TEMP 2019")
    
    # increase the white space between the plots
    f.tight_layout(pad=2.0)

    axes1.figure.savefig(route + sep + "reports" + sep + "column_tendency.png")

    return plt.show()


def piechart(labels, sizes):
    """
    Piechart 
    """
    fig, ax = plt.subplots(figsize=(10,7), subplot_kw=dict(aspect="equal"))

    wedges, texts, autotexts = ax.pie(sizes, autopct=lambda pct: func(pct, sizes),
                                    textprops=dict(color="w"))

    ax.legend(wedges, labels,
            title="Tasks",
            loc="center left",
            bbox_to_anchor=(1, 0, 0.5, 1))

    #ax.figure.savefig(route + sep + "reports" + sep + "piechart.png")

    plt.setp(autotexts, size=8, weight="bold")

    return plt.show()