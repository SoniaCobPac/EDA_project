import pandas as pd 
import os
import sys
import re
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
#import utils.folders_tb as fol  

# The route of this file is added to the sys path to be able to import/export functions
sep = os.sep
def route ():
    """
    This function appends the route of the file to the sys path
    to be able to import files from/to other foders within the EDA project folder.
    """
    route = __file__
    for i in range(3):
        route = os.path.dirname(route)
    sys.path.append(route)
    return route

# Function to read air pollutant data:
def read_data(pollutant, year1, year2):
    """
    This function returns a dataframe from a csv file

    Params: It takes the name of the pollutant (str),
    and two years (int) which are the period of time of the available data.
    """
    pollutant_df = pd.DataFrame()
    for i in list(range(year1, year2)):
        try:
            pollutant_year = pd.read_csv(route() + sep + "data" + sep + pollutant + sep + f"{pollutant.upper()}_HH_{i}.csv", sep=";")
            pollutant_df = pd.concat([pollutant_df, pollutant_year])
        except Exception: 
            continue
    return pollutant_df

def rename_region(dataframe_name):
    """
    Rename the code region to their actual name for ease of understanding.
    
    Param: Dataframe to rename and
    dictionary relating the region codes to their name.
    """
    # Dictionary showing the relation beteween location code and name. This information has been taken from the data source portal
    region = {"1":"ÁLAVA", "2":"ALBACETE", "3":"ALICANTE", "4":"ALMERÍA", "5":"ÁVILA", "6":"BADAJOZ", "7":"ISLAS BALEARES", 
    "8":"BARCELONA", "9":"BURGOS", "10":"CÁCERES", "11":"CÁDIZ", "12":"CASTELLÓN", "13":"CIUDAD REAL", "14":"CÓRDOBA", 
    "15":"A CORUÑA", "16":"CUENCA", "17":"GIRONA", "18":"GRANADA", "19":"GUADALAJARA", "20":"GUIPÚZCOA", "21":"HUELVA", 
    "22": "HUESCA", "23":"JAÉN", "24":"LEÓN", "25":"LLEIDA", "26":"LA RIOJA", "27":"LUGO", "28":"MADRID", "29":"MÁLAGA",
    "30":"MURCIA", "31":"NAVARRA", "32":"OURENSE", "33":"ASTURIAS", "34":"PALENCIA", "35":"LAS PALMAS", "36":"PONTEVEDRA", 
    "37":"SALAMANCA", "38":"SANTA CRUZ DE TENERIFE", "39":"CANTABRIA", "40": "SEGOVIA", "41":"SEVILLA", "42":"SORIA",
    "43":"TARRAGONA", "44":"TERUEL", "45":"TOLEDO", "46":"VALENCIA", "47":"VALLADOLID", "48":"VIZCAYA", "49":"ZAMORA", "50":"ZARAGOZA"}
    region_values = []
    # The dataframe shows a code region = 51 but the documentation doesn't provide its name, 
    # as its location cannot be determined it will be deleted from the table
    dataframe_name = dataframe_name.loc[dataframe_name["PROVINCIA"] != 51]  
    col = dataframe_name["PROVINCIA"].tolist()
    for data in col:
        for keys, values in region.items():
            if str(data) == keys:
                data = values
                region_values.append(data)
        
    dataframe_name["PROVINCIA"] = region_values
    return dataframe_name 

def missing_value(dataframe):
    """
    Missing values and their percentage for each column
    are calculated.

    Param: The dataframe to analyse.
    """
    missing_values = dataframe.isnull().sum()
    missing_percent = 100 * dataframe.isnull().sum() / len(dataframe)
    return missing_values, missing_percent

def clean_dataset(dataframe):
    """
    This functions removes redundant columns 
    and rename the remaining ones for its ease of understanding.

    Param: The dataframe to clean. 
    """
    # Delete unnecessary columns
    cols = ["MUNICIPIO", "ESTACION", "MAGNITUD", "PUNTO_MUESTREO", "DIA"]
    dataframe.drop(cols, axis=1, inplace=True)  
    # Rename kept columns 
    dataframe.rename(columns={"PROVINCIA":"REGION", "ANNO":"YEAR", "MES":"MONTH"}, inplace=True)
    # Remove nan values
    dataframe = dataframe.dropna()

    # In this dataframe a comma is used to separate decimal values, so they are replaced by a point to then be able
    # to convert the number to float
    dataframe = dataframe.replace({',': '.'}, regex=True)
    
    return dataframe


def numbers_to_float(dataframe_section):
    """
    Function to convert object type elements to float type elements.
    Param: Dataframe contaning the elements to transform, and 
    the number of the starting column from where the transformation will start.
    """
    dataframe_section = dataframe_section.astype(float)
    return dataframe_section

def mean_year(dataframe, pollutant):
    """
    This functions returns the mean value of a pollutant in a given region and year
    """
    
    #  the mean value per month is calculated
    dataframe = pd.concat([dataframe.iloc[:,:3], dataframe.iloc[:,4:].mean(axis=1)], axis=1)

    dataframe = dataframe.pivot_table(index=["REGION", "YEAR"], columns="MONTH")
    dataframe = dataframe.mean(axis=1)
    dataframe = pd.DataFrame(dataframe)

    dataframe.rename(columns={0: pollutant}, inplace=True)
    return dataframe


# Save cleaned data in the appropriate folder, in this case it is the folder 'data'
def save_cleaned_data(dataframe, dataframe_name):
    """
    This function creates csv files with the cleaned data.
    Param: Dataframe to save, dataframe name as string to save the data with that name
    """
    dataframe.reset_index(inplace = True)
    if "index" in dataframe.columns:
        dataframe.drop(columns = "index", inplace = True)
    dataframe.to_csv(route() + sep + "data" + sep + "cleaned_data" + sep + dataframe_name + ".csv", index=False)
    return "Your file has been saved"

# Call the cleaned dataframes
def read_cleaned_data(filename):
    """
    To read the previously cleaned dataframes.
    
    Param: The filename (str) on which the information is wanted.
    """
    try:
        filename_df = pd.read_csv(route() + sep + "data" + sep + "cleaned_data" + sep + filename + ".csv", sep=",")  
        return filename_df
    except:
        print("No file with such name has been found")

def read_all (pollutant, pollutant1, pollutant2, pollutant3, pollutant4):  
    """
    Function to read all imported pollutant data
    """
    pollutant = read_data(pollutant, 2014,2020)
    pollutant1 = read_data(pollutant1, 2014,2020)
    pollutant2 = read_data(pollutant2, 2014,2020)
    pollutant3 = read_data(pollutant3, 2014,2020)
    pollutant4 = read_data(pollutant4, 2014,2020)

    return pollutant, pollutant1, pollutant2, pollutant3, pollutant4

def clean_all (pollutant_dataframe): 
    """
    Function to clean all pollutant dataframes
    """
    pollutant_dataframe = rename_region(pollutant_dataframe)
    pollutant_dataframe= clean_dataset(pollutant_dataframe)
    pollutant_dataframe.iloc[:,3:] = numbers_to_float(pollutant_dataframe.iloc[:,3:])
    return pollutant_dataframe

def final_air_dataframe(pollutant_data, pollutant1_data, pollutant2_data, pollutant3_data, pollutant4_data):
    """
    Function to create the final dataframe including all studied pollutant
    """
    pol = pollutant_data.melt(id_vars=("REGION", "YEAR"), value_vars="O3")
    pol1 = pollutant1_data.melt(id_vars=("REGION", "YEAR"), value_vars="SO2")
    pol2 = pollutant2_data.melt(id_vars=("REGION", "YEAR"), value_vars="NO2")
    pol3 = pollutant3_data.melt(id_vars=("REGION", "YEAR"), value_vars="CO")
    pol4 = pollutant4_data.melt(id_vars=("REGION", "YEAR"), value_vars="PM10")

    air = pd.concat([pol, pol1, pol2, pol3, pol4])
    air.rename(columns={"variable": "POLLUTANT", "value": "VALUE"}, inplace=True)
    return air


def same_region(air_data, temp_data):
    """
    Function to check which same regions exist in two different dataframes
    """
    region_list = []
    for elem in air_data["REGION"].unique():
        if elem in temp_data.columns:
            region_list.append(elem)
    return (f"This are the common regions in both datasets, therefore the analysis will be focused on them:\n\n {region_list}")


#-------------------------------------TEMPERATURE DATA RELATED FUNCTIONS-------------------------------------------------

def scrap_func (url, chrome_driver_path):
    """
    Function that access the web to obtain data 
    """
    options = webdriver.ChromeOptions()
    # To avoid opening the website while running the code:
    #options.add_argument("headless")

    # The driver to operate the web scrapping is created
    driver = webdriver.Chrome(executable_path = chrome_driver_path, options= options)
    # Webpage from where the data will be scrapped
    driver.get(url)
        
    dataframes = [2,3,4,5,6,7]
    for elem in dataframes:      
        xpath_month = driver.find_element_by_xpath(f"/html/body/div[3]/div[2]/div[2]/div/table[{elem}]/tbody/tr[3]/td[4]/div/a")
        xpath_month.click()
        xpath_month = driver.find_element_by_xpath(f"/html/body/div[3]/div[2]/div[2]/div/table[{elem}]/tbody/tr[4]/td[4]/div/a")
        xpath_month.click()


def read_temperature(filename):
    """
    This function returns a temperature dataframe from a xlsx file downloaded 
    by web scrapping from Aemet website.

    Params: It takes the name of the filename to read.
    """
    temp_df = pd.read_excel(route() + sep + "data" + sep + "temperatures" + sep + filename + ".xls")
    return temp_df


def clean_temp_data(dataframe):
    """
    This function doesn't return anything, instead it creates csv files with the cleaned data.
    It can be chosen if the information about all pollutants can be saved at once or only the one you are interested.

    Param: filename is a str
    """
    # Drop missing values
    cleaned_df = dataframe.dropna(axis=0)
    
    # Rename the columns, their names is in the first raw so it is removed to about duplicates
    cleaned_df = cleaned_df.rename(columns=cleaned_df.iloc[0])
    cleaned_df = cleaned_df.drop(cleaned_df.index[0])
    
    cleaned_df.rename(columns={"Provincia": "REGION", "Temperatura máxima (ºC)": "TEMP MAX", "Temperatura mínima (ºC)": "TEMP MIN", "Temperatura media (ºC)": "MEAN TEMP"}, inplace=True)

    cleaned_df = cleaned_df.reset_index(drop=True)

    # Maintain only the temperature value in each celd
    min_list = []
    max_list = []

    for i in list(range(1,len(cleaned_df))):
        min_list.append(cleaned_df["TEMP MIN"][i][:4])
        max_list.append(cleaned_df["TEMP MAX"][i][:4])

    cleaned_df["TEMP MIN (ºC)"] = pd.Series(min_list)
    cleaned_df["TEMP MAX (ºC)"] = pd.Series(max_list)
    cleaned_df["TEMP MIN"] = cleaned_df["TEMP MIN (ºC)"]
    cleaned_df["TEMP MAX"] = cleaned_df["TEMP MAX (ºC)"]

    # Change region to uppercase to allow concatenation with air pollutants data
    cleaned_df["REGION"] = cleaned_df["REGION"].apply(lambda x: str(x).upper())

    cols = [0,5,6,7,8,9,10,11,-2,-1]
    cleaned_df.drop(cleaned_df.columns[cols], axis=1, inplace=True)

    return cleaned_df

def translate_region(dataframe):
    """
    To rename a column data to maintain only the Spanish version of their name
    """
    column_list = dataframe["REGION"].to_list()
    output = []
    for elem in column_list:
        if re.findall(r'/\w+', elem):
            result = " ".join(re.findall(r'/\w+', elem))
            output.append(result)

    dataframe = dataframe.mask(dataframe == "ALACANT/ALICANTE", output[0][1:])
    dataframe = dataframe.mask(dataframe == "ARABA/ÁLAVA", output[1][1:])
    dataframe = dataframe.mask(dataframe == "CASTELLÓ/CASTELLÓN", output[2][1:])
    dataframe = dataframe.mask(dataframe == "VALÈNCIA/VALENCIA", output[3][1:])
    dataframe = dataframe.mask(dataframe == "ILLES BALEARS", "ISLAS BALEARES")

    return dataframe

def grouped_data (dataframe):
    """
    Function to calculated the mean temperature per region 
    """
    #dataframe = dataframe.T     
    temp_max = dataframe.groupby("REGION")["TEMP MAX"].max()
    temp_min = dataframe.groupby("REGION")["TEMP MIN"].min()

    # Only the mean temperature column couldn't be calculated as it was an object type
    dataframe["MEAN TEMP"] = dataframe["MEAN TEMP"].astype(float)
    temp_mean = dataframe.groupby("REGION")["MEAN TEMP"].mean()

    final_dataframe = pd.DataFrame([temp_max, temp_min, round(temp_mean,2)])
    
    return final_dataframe

# Call, clean and return all raw data at once
def all_in_one(temp_period):
    """
    Function to call, clean and return temperature dataframes
    """
    dataframe = read_temperature(temp_period)
    dataframe = clean_temp_data(dataframe)
    dataframe = translate_region(dataframe)
    dataframe.iloc[:,1:] = numbers_to_float(dataframe.iloc[:,1:])
    dataframe = grouped_data (dataframe)
    return dataframe

def mean_temp_year(dataframe1, dataframe2):
    """
    Calculate the mean temperature per year based on the 
    mean temperature during two months
    """
    sum = dataframe1.T["MEAN TEMP"] + dataframe2.T["MEAN TEMP"]
    # Divided by two because we are calculating the mean value of two columns
    mean = sum/2
    return mean


def combination(air_data, temp_data):
    """
    Function that merges two dataframes
    """
    temp = temp_data.T
    temp.reset_index(inplace=True)

    final_df = pd.merge(air_data, temp, on="REGION", how="inner")  
    final_df.rename(columns={0:"TEMP 2014", 1: "TEMP 2015", 2: "TEMP 2016", 3: "TEMP 2017", 4: "TEMP 2018", 5: "TEMP 2019"}, inplace=True) 
    return final_df

